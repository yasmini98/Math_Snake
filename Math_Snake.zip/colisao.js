function colisao(){
  
  if(praOndeVou == "direita"){
    
     //pra bolinha C1
     if( dist(posXc1, posYc1, posX+largura, posY+altura/2)  < diam/2  ){
       
       somDoJogo.stop()
       somErrou.play()
       console.log("GameOver")
       tela = 4
       
     }
    
    //pra bolinha C2 - Aqui sempre é a certa
    if( dist(posXc2, posYc2, posX+largura, posY+altura/2)  < diam/2  ){
       
      
       somAcertou.play()
       console.log("Ganhou")
       pontos += 10
      
       if(pontos % 100 == 0){
         nivel++
       }
      
       sorteio()
       sortearRespostas(r[posicao])
       
     }
    
    //pra bolinha C1
     if( dist(posXc3, posYc3, posX+largura, posY+altura/2)  < diam/2  ){
       
       somDoJogo.stop()
       somErrou.play()
       console.log("GameOver")
       tela = 4
       
     }
    
     
  }
  
  if(praOndeVou == "esquerda"){
    
      //pra bolinha C1
     if( dist(posXc1, posYc1, posX, posY+altura/2)  < diam/2  ){
       
       somDoJogo.stop()
       somErrou.play()
       console.log("GameOver")
       tela = 4
       
     }
    
    //pra bolinha C2 - Aqui sempre é a certa
    if( dist(posXc2, posYc2, posX, posY+altura/2)  < diam/2  ){
       
      somAcertou.play()
       console.log("Ganhou")
       pontos += 10
      
      if(pontos % 100 == 0){
         nivel++
       }
      
       sorteio()
       sortearRespostas(r[posicao])
       
     }
    
    //pra bolinha C1
     if( dist(posXc3, posYc3, posX, posY+altura/2)  < diam/2  ){
       
       somDoJogo.stop()
       somErrou.play()
       console.log("GameOver")
       tela = 4
       
     }
    
    
  }
  
  if(praOndeVou == "baixo"){
    
     //pra bolinha C1
     if( dist(posXc1, posYc1, posX+largura/2, posY+altura)  < diam/2  ){
       
       somDoJogo.stop()
       somErrou.play()
       console.log("GameOver")
       tela = 4
       
     }
    
    //pra bolinha C2 - Aqui sempre é a certa
    if( dist(posXc2, posYc2, posX+largura/2, posY+altura)  < diam/2  ){
       
      somAcertou.play()
       console.log("Ganhou")
       pontos += 10
      
      if(pontos % 100 == 0){
         nivel++
       }
      
       sorteio()
       sortearRespostas(r[posicao])
       
     }
    
    //pra bolinha C1
     if( dist(posXc3, posYc3, posX+largura/2, posY+altura)  < diam/2  ){
       
       somDoJogo.stop()
       somErrou.play()
       console.log("GameOver")
       tela = 4
       
     }
    
  }
  
  if(praOndeVou == "cima"){
    
     //pra bolinha C1
     if( dist(posXc1, posYc1, posX+largura/2, posY)  < diam/2  ){
       
       somDoJogo.stop()
       somErrou.play()
       console.log("GameOver")
       tela = 4
       
     }
    
    //pra bolinha C2 - Aqui sempre é a certa
    if( dist(posXc2, posYc2, posX+largura/2, posY)  < diam/2  ){
       
      somAcertou.play()
       console.log("Ganhou")
       pontos += 10
      
       if(pontos % 100 == 0){
         nivel++
       }
      
       sorteio()
       sortearRespostas(r[posicao])
       
     }
    
    //pra bolinha C1
     if( dist(posXc3, posYc3, posX+largura/2, posY)  < diam/2  ){
       
       somDoJogo.stop()
       somErrou.play()
       console.log("GameOver")
       tela = 4
       
     }
    
  }
  
}