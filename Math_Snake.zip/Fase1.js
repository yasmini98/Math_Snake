var posX = 100;
var posY = 300;

//posição dos círculos
var posXc1, posXc2, posXc3
var posYc1, posYc2, posYc3

var largura = 70, altura = 20, auxiliar;
var velocidade = 1

//diametro dos círculos
var diam = 40

var praOndeVou = "direita"

var nivel = 1, posicao = 0;
var pontos = 0;

//numeros aleatórios
var nC1, nC3

//Nivel1 - vetores
var x = [], y = [], z = [], w = [], sinal = [], r = [], calculo = []

function fase1(){
  
 background("#FFFFFF")
  
  fill('#FF00A0')
  rect(posX, posY, largura, altura)
  
  fill("#FFC300")
  rect(0, 70, 400, 2)
  
  fill("#FFC300")
  rect(0, 0, 400, 70)
  
  fill('#FF00A0')
  rect(10,20,50,30)
  
  textAlign(CENTER)
  fill('#FFFFFF')
  text(" "+pontos,10, 28, 50, 30)
    
  //textAlign(CENTER)
  fill("#ffffff")
  stroke("#8A4B08")
  strokeWeight(5)
  textSize(20)
  text("Calcule: "+calculo[posicao],0, 30, 400, 70)
  
  noStroke()
  
  fill("#045FB4")
  circle(posXc1, posYc1, diam)
  circle(posXc2, posYc2, diam)
  circle(posXc3, posYc3, diam)
  
  textSize(12)
  
  //resposta correta
  fill("#FFFFFF")
  text(r[posicao].toFixed(1),posXc2, posYc2+5);
  
  //respostas erradas
  text(nC1.toFixed(1), posXc1, posYc1+5)
  text(nC3.toFixed(1),posXc3, posYc3+5)
  
  //rect((posX-altura/2), posY, altura, largura)
  
  //posX++
  
  //para baixo
  //rect( (posX+largura)-altura , (posY-largura)+altura, altura, largura)

  if(praOndeVou == "direita"){
    
     posX += velocidade
     
  }
  
  if(praOndeVou == "esquerda"){
    
    posX -= velocidade
    
  }
  
  if(praOndeVou == "baixo"){
    
    posY += velocidade
    
  }
  
  if(praOndeVou == "cima"){
    
    posY -= velocidade
    
  }
  
  
  
  if(posX > 400){
  posX = -largura
  }
  
  if(posX < -largura){
    
    posX = 400
    
  }
  
  if(posY > 400){
    
    posY = -altura+70
    
  }
  
  if(posY < - altura+70){
    
    posY = 400
    
  }
  
  colisao()
  
  if(pontos == 300){
    
    tela = 5
    
  }
  
}