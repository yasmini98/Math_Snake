//Youtube video de explicação: https://youtu.be/EHga9hcoca0

function créditos(){
  
  background("#ffc300")
  textAlign(LEFT)
  
  stroke("ffffff")
  strokeWeight(2)
  fill("#ffffff")
  textSize(50)
  text("  Créditos", 85, 70)  
  noStroke("#000000")
  
  textSize(14)
  fill("#ffffff")
  text('Jogo criado por Yasmini Oliveira, aluna de Ciências e', 23, 130)
  text('Tecnologia pela Universidade Federal do Rio Grande', 23, 160)
  text('do Norte.', 23, 190 )
  text('Agradecimento especial ao professor Aquiles Burlamaqui', 23, 220)
  text('pelos ensinamentos em Lógica de Programação e ao', 23, 250)
  text('monitor Pablo Durkheim pelo apoio na execução deste', 23, 280)
  text('game.', 23, 310)
 // text('Músicas: ', 23, 340)

  circle(30, 370, 35)
  fill("#ff00a0")
  text('<<', 19.5, 375.5)
  

}