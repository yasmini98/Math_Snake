function gameover(){


background("#ffffff");
 // rect(150, 160, 100, 35)
 // rect(150, 200, 100, 35)
 textAlign(CENTER)
 

 
  stroke("#ff00a0")
  strokeWeight(2)
  fill("#ff00a0")
  textSize(50)
  text("Game Over", 0, 170, 400, 400)  
 noStroke("#000000")
  
// text('Jogar', 179, 172, 100, 35)
//  text('Instruções', 150, 212, 100, 35)
  text(" "+pontos, 150, 260, 100, 50)
  
  
  textSize(17)
  circle(30, 370, 35)
  fill("#ffffff")
  text('<<', 28, 375.5)
  
  
  // para voltar ao menu
  
  
 

}