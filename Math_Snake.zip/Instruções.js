  function instruções(){
  background("#ff00a0");
  textAlign(LEFT)
  
  stroke("ffffff")
  strokeWeight(2)
  fill("#ffffff")
  textSize(50)
  text("Instruções", 85, 70)  
  noStroke("#000000")
  
  textSize(17)
  fill("#ffffff")
  text('Você tem apenas uma missão: controlar a', 23, 130)
  text('Math Snake com as setas do teclado para', 23, 160)
  text('que vá em direção às comidas corretas,', 23, 190 )
  text('e as comidas corretas são as respostas', 23, 220)
  text('das equações que aparecerão na tela.', 23, 250)
  text('Caso a Math Snake se alimente da comida', 23, 280)
  text('errada ela morrerá e seus pontos serão', 23, 310)
  text('contabilizados.', 23, 340)

  circle(30, 370, 35)
  fill("#ff00a0")
  text('<<', 19.5, 375.5)
  
  if( (tela == 1 || tela == 2) && dist(30, 370, mouseX, mouseY) <= (35/2)){
    
    
  }
  
}
  