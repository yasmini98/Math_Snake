var tela = 0;

//audio
var somMenu, somAcertou, somErrou, somDoJogo, somInstruCred 

function preload(){
  
  somMenu = createAudio('sons_jogo/menu otimizado.mp3')
  somAcertou = createAudio('sons_jogo/comidinha certa.mp3')
  somErrou = createAudio('sons_jogo/comidinha errada.mp3')
  somDoJogo = createAudio('sons_jogo/durante jogo otimizado.mp3')
  somInstruCred = createAudio('sons_jogo/instrucoes e creditos.mp3')
  
}

function setup() {
  createCanvas(400, 400);
  
  sorteio()
  sortearRespostas(r[posicao])
}

function draw() {
  background(220);
  
  //menu/
  if(tela == 0){
    menu();
  }
  
  //instruções/
  if(tela == 1){
    instruções();
  }
  
  //créditos/
  if(tela == 2){
    créditos();
  }
  
  //começar jogo
  if(tela == 3){
    fase1();
    
  }
  
  //tela "perdeu"
  if(tela == 4){
    gameover();
  }
  
  //tela "ganhou"
  if(tela == 5){
    ganhou()
  }
}