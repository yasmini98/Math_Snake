function ganhou(){


background("#ffffff");

  textAlign(CENTER)
  stroke("#ff00a0")
  strokeWeight(2)
  fill("#ff00a0")
  textSize(50)
  text("Ganhou!", 0, 150, 400, 50)  
  
  text(" "+pontos, 150, 260, 100, 50)
  fill("#ff00a0")
  
  
  textSize(17)
  circle(30, 370, 35)
  fill("#ffffff")
  text('<<', 28, 375.5)

  //para voltar ao menu
   function mouseClicked(){
    
    if ((tela == 5) && dist(30, 370, mouseX, mouseY) <= (35/2)){
      
      tela = 0
    }
   }
}