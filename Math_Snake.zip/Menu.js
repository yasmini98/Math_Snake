function menu(){
  
  background("#ffffff");
  rect(150, 160, 100, 35)
  rect(150, 200, 100, 35)
  rect(150, 240, 100, 35)

  textAlign(CENTER)
 
  stroke("#ff00a0")
  strokeWeight(2)
  fill("#ff00a0")
  textSize(50)
  text(" Math Snake", 0, 30, 400,70)  
  noStroke("#000000")
  textSize(17)
  fill("#ffffff")
  text(' Jogar', 150, 172, 100, 35)
  text(' Instruções', 150, 212, 100, 35)
  text(' Créditos', 150, 252, 100, 35)
  fill("#ff00a0")
  
}