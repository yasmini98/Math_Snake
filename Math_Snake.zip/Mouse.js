var mouseMoveu = false

function mouseClicked(){
  
  console.log("X: "+mouseX+" Y: "+mouseY)
  
  if(tela == 0){
    
    //jogar
  if(mouseX>=150 && mouseX<=250 && mouseY>=160 && mouseY<=195){
    tela = 3
    
    somMenu.stop()
    somDoJogo.loop()
    
    sorteio()
    sortearRespostas(r[posicao])
    
    //console.log("Jogar")
  }
  
  //instruções
  if(mouseX>=150 && mouseX<=250 && mouseY>=200 && mouseY<=235){
    tela = 1
    //console.log("Instruções")
  }
  
  //créditos
  if(mouseX>=150 && mouseX<= 250 & mouseY >=240 && mouseY<=275){
    tela = 2
    //console.log("Créditos")
  }
    
  }else{
    
    if( (tela == 1 || tela == 2 || tela == 4 || tela == 5) && dist(30, 370, mouseX, mouseY) <= (35/2)){
    
    //console.log(tela)
    
    somInstruCred.play()
      
    tela = 0
      
    //zerar: deixar nas condições iniciais do jogo
    praOndeVou = "direita"
    largura = 70
    altura = 20
    nivel = 1
    posicao = 0
    pontos = 0
    
    //Começou a dar problema quando 
    //coloquei essa opção de voltar
    //para o menu.
  }
    
  }
  
  
  
  
  
}

function mouseMoved(){
  
  if(mouseMoveu == false){
    
    somMenu.loop()
    mouseMoveu = true
    
  }
  
}