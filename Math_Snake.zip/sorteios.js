var expressao

function sorteio(){
  
  //sorteia a posição das bolinhas
  posXc1 = parseInt(random(diam/2, 400-diam/2))
  posXc2 = parseInt(random(diam/2, 400-diam/2))
  posXc3 = parseInt(random(diam/2, 400-diam/2))
  posYc1 = parseInt(random(70+diam/2, 400-diam/2))
  posYc2 = parseInt(random(70+diam/2, 400-diam/2))
  posYc3 = parseInt(random(70+diam/2, 400-diam/2))
  
  //verifica se tá próximo da cobrinha
  while(dist(posX+largura/2, posY+altura/2,posXc1,posYc1) < (36.40+ diam/2) ){
    
      posXc1 = parseInt(random(diam/2, 400-diam/2))
      posYc1 = parseInt(random(70+diam/2, 400-diam/2))
    
  }
  
  //verifica se bateu na bolinha 1 ou na cobrinha
  while(dist(posXc2, posYc2, posXc1, posYc1) < diam || 
       dist(posX+largura/2, posY+altura/2,posXc2,posYc2) < (36.40+ diam/2) ){
    
     posXc2 = parseInt(random(diam/2, 400-diam/2))
     posYc2 = parseInt(random(70+diam/2, 400-diam/2))
    
    
    
  }
  
  //verifica se bateu na bolinha 1 ou 2 ou na cobrinha
  while(dist(posXc3, posYc3, posXc1, posYc1) < diam || dist(posXc3, posYc3, posXc2, posYc2) < diam || dist(posX+largura/2, posY+altura/2,posXc3,posYc3) < (36.40+ diam/2) ){
    
     posXc3 = parseInt(random(diam/2, 400-diam/2))
     posYc3 = parseInt(random(70+diam/2, 400-diam/2))
    
  }
  
  if(nivel == 1){
    
    sinal = ['+', '-']
    sinalC = [1,-1]
    
    //4 equações
    for(var i = 0; i < 10; i++){
      
      x[i] = parseInt(random(1, 10))
      y[i] = parseInt(random(1, 10))
      z[i] = parseInt(random(1, 10))
      w[i] = parseInt(random(1, 10))
      
      s1 = parseInt(random(0,2))
      s2 = parseInt(random(0,2))
      s3 = parseInt(random(0,2))
      
      //armazena a resposta correta
      r[i] = x[i] + sinalC[s1]*y[i] + sinalC[s2]*z[i] + sinalC[s3]*w[i]
      
      //armazena o formato da equação
      calculo[i] = x[i]+sinal[s1]+y[i]+sinal[s2]+z[i]+sinal[s3]+w[i]+" = "
      
      //console.log(x[i]+sinal[s1]+y[i]+sinal[s2]+z[i]+sinal[s3]+w[i]+" = "+r[i])
      
    }
    
    
  }
  
  
  if(nivel == 2){
    
    sinal = ['+', '-', '/','*']
    sinalC = [1,-1]
    
    //8 equações
    for(var j = 0; j < 10; j++){
      
      x[j] = parseInt(random(1, 10))
      y[j] = parseInt(random(1, 10))
      z[j] = parseInt(random(1, 10))
      w[j] = parseInt(random(1, 10))
      
      s1 = parseInt(random(0,4))
      s2 = parseInt(random(0,4))
      s3 = parseInt(random(0,4))
      
      r[j] = x[j]+sinal[s1]+y[j]+sinal[s2]+z[j]+sinal[s3]+w[j]
      
      r[j] = eval(r[j])
      
      //limitando o resultado em 2 digitos
      while(r[j] < 0 || r[j] > 99){
        
          x[j] = parseInt(random(1, 10))
          y[j] = parseInt(random(1, 10))
          z[j] = parseInt(random(1, 10))
          w[j] = parseInt(random(1, 10))
      
          s1 = parseInt(random(0,4))
          s2 = parseInt(random(0,4))
          s3 = parseInt(random(0,4))
      
          r[j] = x[j]+sinal[s1]+y[j]+sinal[s2]+z[j]+sinal[s3]+w[j]
      
          r[j] = eval(r[j])
        
      }
     
     calculo[j] = x[j]+" "+sinal[s1]+" "+y[j]+" "+sinal[s2]+" "+z[j]+" "+sinal[s3]+" "+w[j]+" = "
      
    }
    
    
  }
  
  if(nivel == 3){
    
     sinal = ['+', '-', '/','*','2','sqrt(']
    
     //8 equações
    for(var k = 0; k < 10; k++){
      
      x[k] = parseInt(random(1, 10))
      y[k] = parseInt(random(1, 10))
      z[k] = parseInt(random(1, 10))
      w[k] = parseInt(random(1, 10))
      
      s1 = parseInt(random(0,4))
      s2 = parseInt(random(0,4))
      s3 = parseInt(random(0,4))
      expoente = parseInt(random(0,4))
      raiz = parseInt(random(0,4))
      
      if(expoente == 0){
        x[k] = x[k]+'**2'
      }
      if(expoente == 1){
        y[k] = y[k]+'**2'
      }
      if(expoente == 2){
        z[k] = z[k]+'**2'
      }
      if(expoente == 3){
        w[k] = w[k]+'**2'
      }
      
      if(raiz == 0){
        x[k] = 'sqrt('+x[k]+')'
      }
      if(raiz == 1){
        y[k] = 'sqrt('+y[k]+')'
      }
      if(raiz == 2){
        z[k] = 'sqrt('+z[k]+')'
      }
      if(raiz == 3){
        w[k] = 'sqrt('+w[k]+')'
      }
      
       r[k] = x[k]+sinal[s1]+y[k]+sinal[s2]+z[k]+sinal[s3]+w[k]
      
      r[k] = eval(r[k])
      
       calculo[k] = x[k]+" "+sinal[s1]+" "+y[k]+" "+sinal[s2]+" "+z[k]+" "+sinal[s3]+" "+w[k]+" = "
      
        expressao = calculo[k]
        
        expressao = expressao.replace('sqrt','raiz')
        
        calculo[k] = expressao
      
      while(r[k] < 0 || r[k] > 99){
        
          x[k] = parseInt(random(1, 10))
          y[k] = parseInt(random(1, 10))
          z[k] = parseInt(random(1, 10))
          w[k] = parseInt(random(1, 10))
      
          s1 = parseInt(random(0,4))
          s2 = parseInt(random(0,4))
          s3 = parseInt(random(0,4))
          expoente = parseInt(random(0,4))
          raiz = parseInt(random(0,4))
      
          if(expoente == 0){
            x[k] = x[k]+'**2'
          }
          if(expoente == 1){
            y[k] = y[k]+'**2'
          }
          if(expoente == 2){
            z[k] = z[k]+'**2'
          }
          if(expoente == 3){
            w[k] = w[k]+'**2'
          }
      
          if(raiz == 0){
            x[k] = 'sqrt('+x[k]+')'
          }
          if(raiz == 1){
            y[k] = 'sqrt('+y[k]+')'
          }
          if(raiz == 2){
            z[k] = 'sqrt('+z[k]+')'
          }
          if(raiz == 3){
            w[k] = 'sqrt('+w[k]+')'
          }
      
         r[k] = x[k]+sinal[s1]+y[k]+sinal[s2]+z[k]+sinal[s3]+w[k]
      
         r[k] = eval(r[k])
      
       calculo[k] = x[k]+" "+sinal[s1]+" "+y[k]+" "+sinal[s2]+" "+z[k]+" "+sinal[s3]+" "+w[k]+" = "
        
        expressao = calculo[k]
        
        expressao = expressao.replace('sqrt','raiz')
        
        calculo[k] = expressao
        
        
      }
      
    }
    
  }
  
   
  
}

function sortearRespostas(resposta){
  
    //sorteia o valor dos circulos e verifica se é inteiro ou float
  
    if(resposta - parseInt(resposta) == 0){
      
       nC1 = parseInt(random(resposta - 10, resposta+10))
    nC3 = parseInt(random(resposta - 10, resposta + 10))
      
      while(nC1 == resposta){
        nC1 = parseInt(random(resposta - 10, resposta+10))
      }
      
      while(nC3 == resposta){
        nC3 = parseInt(random(resposta - 10, resposta + 10))
      }
      
    }else{
      
      nC1 = parseFloat(random(resposta - 10, resposta +10))
    nC3 = parseFloat(random(resposta - 10, resposta +10))
      
      while(nC1 == resposta){
         nC1 = parseFloat(random(resposta - 10, resposta +10))   
      }
      
      while(nC3 == resposta){
        nC3 = parseFloat(random(resposta - 10, resposta +10))
      }
      
    }
  
   console.log(resposta)
  
}