function keyPressed() {
  
  //se estiver na tela do jogo
  if(tela == 3){
    
     //direita
     if (keyCode === RIGHT_ARROW && praOndeVou != "direita" && praOndeVou != "esquerda") {
       
       //se estiver vindo de cima
       if(praOndeVou == "cima"){
         
          posX = posX-altura/2
       
          auxiliar = largura
          largura = altura
          altura = auxiliar
         
       }
       
       //se estiver vindo de baixo
       if(praOndeVou == "baixo"){
         
           posX = posX-altura/2
           posY = (posY+altura)-largura
           
         
          auxiliar = largura
          largura = altura
          altura = auxiliar
         
       }
      
       
       praOndeVou = "direita"
       
    } 
    
     //esquerda
     if (keyCode === LEFT_ARROW && praOndeVou != "direita" && praOndeVou != "esquerda") {
       
       //se estiver vindo de cima
       if(praOndeVou == "cima"){
         
          auxiliar = largura
          largura = altura
          altura = auxiliar
         
       }
       
       if(praOndeVou == "baixo"){
         
         posX = posX-altura/2
         posY = (posY+altura)-largura
         
         
          auxiliar = largura
          largura = altura
          altura = auxiliar
         
       }
       
      
       
       praOndeVou = "esquerda"
       
    } 
    
    //vai para baixo
    if (keyCode === DOWN_ARROW && praOndeVou != "cima" && praOndeVou != "baixo") {
       
        if(praOndeVou == "direita"){
          
           posX = (posX+largura)-altura
           posY = (posY-largura/2)+altura
        
           auxiliar = largura
           largura = altura
           altura = auxiliar
          
        }
       
        if(praOndeVou == "esquerda"){
          
           posY = (posY-largura/2)+altura
        
           auxiliar = largura
           largura = altura
           altura = auxiliar
          
        }
      
        praOndeVou = "baixo"
       
    } 
    
    //vai para cima
    if(keyCode === UP_ARROW && praOndeVou != "cima" && praOndeVou != "baixo"){
      
        
      if(praOndeVou == "direita"){
        
         posX = (posX+largura)-altura
         posY = (posY)-altura/2
      
         auxiliar = largura
         largura = altura
         altura = auxiliar 
        
      }
      
      if(praOndeVou == "esquerda"){
        
         posY = (posY)-altura/2
      
         auxiliar = largura
         largura = altura
         altura = auxiliar 
        
      }
      
       
      
       praOndeVou = "cima"
      
    }
    
  }
  
  
}
